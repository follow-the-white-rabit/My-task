package com.company;

public class Main {

    public static void main(String[] args) {
        PenCreator gladerPenCreator = new GladerPenCreator();
        gladerPenCreator.writeDocument();

        PenCreator maxWritePenCreator = new MaxWritePenCreator();
        maxWritePenCreator.createPen();
        maxWritePenCreator.writeDocument();
    }
}
