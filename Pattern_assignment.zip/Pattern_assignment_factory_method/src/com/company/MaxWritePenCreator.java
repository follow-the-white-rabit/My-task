package com.company;

public class MaxWritePenCreator extends PenCreator{
    @Override
    Pen createPen() {
        return new MaxWriterPen();
    }
}
