package com.company;

public class GladerPen implements Pen {
    @Override
    public void write() {
        System.out.println("I'm writing with GladerPen!");
    }

    @Override
    public void sign() {
        System.out.println("I'm signing with GladerPen!");
    }
}
