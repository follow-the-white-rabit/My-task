package com.company;

public class MaxWriterPen implements Pen {
    @Override
    public void write() {
        System.out.println("I'm writing with MaxWriter pen!");
    }

    @Override
    public void sign() {
        System.out.println("I'm signing with MaxWriter pen!");
    }
}
