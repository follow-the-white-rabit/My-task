package com.company;

public abstract class PenCreator{
    void writeDocument(){
        Pen pen = createPen();
        pen.write();
        pen.sign();
    }

    abstract Pen createPen();
}
