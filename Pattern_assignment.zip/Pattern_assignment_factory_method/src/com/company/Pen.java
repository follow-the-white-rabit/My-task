package com.company;

public interface Pen {
    void write();
    void sign();
}
