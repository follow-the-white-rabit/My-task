package com.company;

public class GladerPenCreator extends PenCreator{
    @Override
    Pen createPen() {
        return new GladerPen();
    }
}
