package com.company;

public class IndesitMicrowaveOven implements MicrowaveOven{
    @Override
    public void hasDoor() {
        System.out.println("Indesit MicrowaveOven has one door and sensor button to open/close the door.");
    }

    @Override
    public void hasMotor() {
        System.out.println("Indesit MicrowaveOven has motor that generates wave at specific volume.");
    }
}
