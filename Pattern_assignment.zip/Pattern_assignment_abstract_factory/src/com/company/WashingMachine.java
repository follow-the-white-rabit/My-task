package com.company;

public interface WashingMachine {
    void hasDoor();
    void hasMotor();
}
