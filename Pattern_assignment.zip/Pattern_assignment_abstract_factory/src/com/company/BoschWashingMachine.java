package com.company;

public class BoschWashingMachine implements WashingMachine{
    @Override
    public void hasDoor() {
        System.out.println("Bosch WashingMachine has one mechanical door.");
    }

    @Override
    public void hasMotor() {
        System.out.println("Bosch WashingMachine motor moves drum in different speeds.");
    }
}
