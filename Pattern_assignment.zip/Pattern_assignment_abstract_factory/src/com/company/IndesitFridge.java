package com.company;

public class IndesitFridge implements Fridge{
    @Override
    public void hasDoor() {
        System.out.println("Indesit Fridge has two doors, one big and one smaller for freezer.");
    }

    @Override
    public void hasMotor() {
        System.out.println("Indesit fridge compressor is both a motor and pump that move the refrigerant through the system.");
    }
}
