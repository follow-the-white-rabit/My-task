package com.company;

public class IndesitWashingMachine implements WashingMachine{
    @Override
    public void hasDoor() {
        System.out.println("Indesit WashingMachine has one door and sensor button to open/close the door.");
    }

    @Override
    public void hasMotor() {
        System.out.println("Indesit WashingMachine has motor that moves drum at specific speeds.");
    }
}
