package com.company;

public class Main {

    public static void main(String[] args) {
        technicalFactory indesitFactory = new IndesitFactory();
        Fridge fridge = indesitFactory.createFridge();
        System.out.println("Fridge description:");
        fridge.hasDoor();
        fridge.hasMotor();

        technicalFactory BoschFactory = new BoschFactory();
        MicrowaveOven microwaveOven = new BoschMicrowaveOven();
        System.out.println("Microwave Oven description:");
        microwaveOven.hasDoor();
        microwaveOven.hasMotor();
    }
}
