package com.company;

public class BoschFridge implements Fridge{
    @Override
    public void hasDoor() {
        System.out.println("Bosch Fridge has two doors and one freezer section within.");
    }

    @Override
    public void hasMotor() {
        System.out.println("Bosch Fridge uses powerful motor.");
    }
}
