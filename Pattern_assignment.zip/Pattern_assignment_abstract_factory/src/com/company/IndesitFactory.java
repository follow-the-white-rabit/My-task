package com.company;

public class IndesitFactory implements technicalFactory{
    @Override
    public Fridge createFridge() {
        return new BoschFridge();
    }

    @Override
    public MicrowaveOven createMicrowaveOven() {
        return new BoschMicrowaveOven();
    }

    @Override
    public WashingMachine createWashingMachine() {
        return new BoschWashingMachine();
    }
}
