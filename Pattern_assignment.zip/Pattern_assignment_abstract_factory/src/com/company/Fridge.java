package com.company;

public interface Fridge {
    void hasDoor();
    void hasMotor();
}
