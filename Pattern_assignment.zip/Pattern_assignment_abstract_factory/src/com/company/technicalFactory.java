package com.company;

public interface technicalFactory {
    Fridge createFridge();
    MicrowaveOven createMicrowaveOven();
    WashingMachine createWashingMachine();
}
