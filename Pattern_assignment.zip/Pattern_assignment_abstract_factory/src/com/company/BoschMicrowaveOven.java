package com.company;

public class BoschMicrowaveOven implements MicrowaveOven{
    @Override
    public void hasDoor() {
        System.out.println("Bosch MicrowaveOven has one mechanical door.");
    }

    @Override
    public void hasMotor() {
        System.out.println("Bosch MicrowaveOven has one mechanical motor.");
    }
}
