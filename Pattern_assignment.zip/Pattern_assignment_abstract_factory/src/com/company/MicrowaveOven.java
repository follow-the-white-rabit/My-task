package com.company;

public interface MicrowaveOven {
    void hasDoor();
    void hasMotor();
}
